java -Xmx8G -jar Chess.jar 
