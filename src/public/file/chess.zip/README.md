# Big Brain Chess

<p align="center"><img width=200 src="res/img/chess_icon.png"></p>

- [Big Brain Chess](#big-brain-chess)
- [Getting Started](#getting-started)
- [Credits](#credits)
	- [Dependancies:](#dependancies)
	- [Libraries & Sources:](#libraries--sources)
	- [Specifications & Design Documents:](#specifications--design-documents)
- [Authors](#authors)
	- [Team Members:](#team-members)

# Getting Started
1. **Install all dependacies [here](#dependancies).**
2. Clone or download this repository.
3. Run ant to initialize & download libraries
	
	```ant``` - On the first run it should fail as it's downloading libraries

3. Compile the program
	
	```ant jar```

4. Run The Program with

	```java -Xmx8G -jar build/jar/Chess.jar ``` or ```./Chess.sh```(For UNIX)

# Credits
## Dependancies:
- Java 11.0 & Swing
- Apache Ant(TM) version 1.10.5
- 8GB of system memory (Playing against AI)

## Libraries & Sources:
- UI elements tweaked & edited from **[Font Awesome](https://fontawesome.com/license)**
- Chess icons from **[wpclipart](https://www.wpclipart.com/recreation/games/chess/chess_set_1/)**, **[Terms & Conditions](https://www.wpclipart.com/terms.html)**

## Specifications & Design Documents:
Specifications & Design Document [here](https://submit.cs.kingsu.ca/CMPT320-2019F-G1/chess/wikis/Specifications-&-Design-Documents)

Project todo's [here](https://submit.cs.kingsu.ca/CMPT320-2019F-G1/chess/wikis/TODOs).

Progress & Feature Tracker on [trello](https://trello.com/b/pYCUvTz7/cmpt320-chess).

# Authors
Made By: **Group 1 - 2019 (Best Group)**

## Team Members:
*  Dave Sanchez {dave.sanchez@live.ca, mobile: 7802356332}
*  Kalley Lasola {kalleylaso@gmail.com, mobile: 5875014350}
*  Olu Olabimtan {olumideolabimtan@gmail.com, mobile: 7808029550}
*  Elias Mawa {emawa@sawol.ca, mobile: 587-568-8571}